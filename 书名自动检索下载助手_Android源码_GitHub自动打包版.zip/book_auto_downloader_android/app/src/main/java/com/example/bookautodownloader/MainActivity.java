package com.example.bookautodownloader;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "book_auto_downloader_prefs";
    private static final String KEY_SOURCES = "sources_json";
    private static final int MATCH_AUTO_DOWNLOAD_MIN_SCORE = 55;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newFixedThreadPool(4);

    private EditText bookInput;
    private EditText sourceNameInput;
    private EditText sourceTemplateInput;
    private EditText sourceExtInput;
    private CheckBox autoDownloadCheck;
    private LinearLayout sourceListLayout;
    private LinearLayout resultLayout;
    private TextView logView;

    private final ArrayList<SourceConfig> sources = new ArrayList<>();
    private final ArrayList<SearchResult> latestResults = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadSources();
        if (sources.isEmpty()) {
            sources.add(new SourceConfig("示例：请改成你自己的合法资源站", "https://example.com/search?q={keyword}", "pdf,zip", false));
            saveSources();
        }
        buildUi();
        renderSources();
        handleSharedText(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleSharedText(intent);
    }

    private void handleSharedText(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        String type = intent.getType();
        if (Intent.ACTION_SEND.equals(action) && type != null && type.startsWith("text/")) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (!TextUtils.isEmpty(text)) {
                bookInput.setText(text.trim());
                log("收到分享文本：" + text.trim());
            }
        }
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(24));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("书名自动检索下载助手");
        title.setTextSize(23);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, 0, 0, dp(10));
        root.addView(title, mp(-1, -2));

        TextView notice = new TextView(this);
        notice.setText("用途：复制书名后，读取剪贴板，按你配置的合法资源站搜索并下载。仅用于自有、授权、公版或允许分发的资料源。遇到登录/验证码/动态页面时，请用“打开搜索页”手动处理。");
        notice.setTextSize(13);
        notice.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(notice, mp(-1, -2));

        addSectionTitle(root, "1. 书名 / 买家要的资料名");
        bookInput = new EditText(this);
        bookInput.setHint("例如：西门子 S7-1200 PLC 入门教程");
        bookInput.setSingleLine(false);
        bookInput.setMinLines(2);
        root.addView(bookInput, mp(-1, -2));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row1, mp(-1, -2));

        Button clipBtn = new Button(this);
        clipBtn.setText("读取剪贴板");
        clipBtn.setOnClickListener(v -> readClipboard(false));
        row1.addView(clipBtn, lpWeight());

        Button clipSearchBtn = new Button(this);
        clipSearchBtn.setText("读取并搜索");
        clipSearchBtn.setOnClickListener(v -> readClipboard(true));
        row1.addView(clipSearchBtn, lpWeight());

        autoDownloadCheck = new CheckBox(this);
        autoDownloadCheck.setText("搜索后自动下载最高匹配结果");
        autoDownloadCheck.setTextSize(14);
        root.addView(autoDownloadCheck, mp(-1, -2));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row2, mp(-1, -2));

        Button searchBtn = new Button(this);
        searchBtn.setText("开始搜索");
        searchBtn.setOnClickListener(v -> searchAllSources());
        row2.addView(searchBtn, lpWeight());

        Button openBtn = new Button(this);
        openBtn.setText("打开搜索页");
        openBtn.setOnClickListener(v -> openSearchPages());
        row2.addView(openBtn, lpWeight());

        addSectionTitle(root, "2. 配置资源站");
        sourceNameInput = new EditText(this);
        sourceNameInput.setHint("资源站名称，例如：我的资料站");
        root.addView(sourceNameInput, mp(-1, -2));

        sourceTemplateInput = new EditText(this);
        sourceTemplateInput.setHint("搜索链接模板，必须包含 {keyword}\n例如：https://example.com/search?q={keyword}");
        sourceTemplateInput.setSingleLine(false);
        sourceTemplateInput.setMinLines(2);
        root.addView(sourceTemplateInput, mp(-1, -2));

        sourceExtInput = new EditText(this);
        sourceExtInput.setHint("允许下载类型，例如：pdf,zip,rar,7z");
        sourceExtInput.setText("pdf,zip");
        root.addView(sourceExtInput, mp(-1, -2));

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row3, mp(-1, -2));

        Button addSourceBtn = new Button(this);
        addSourceBtn.setText("添加资源站");
        addSourceBtn.setOnClickListener(v -> addSource());
        row3.addView(addSourceBtn, lpWeight());

        Button clearSourcesBtn = new Button(this);
        clearSourcesBtn.setText("清空配置");
        clearSourcesBtn.setOnClickListener(v -> {
            sources.clear();
            saveSources();
            renderSources();
            toast("已清空资源站配置");
        });
        row3.addView(clearSourcesBtn, lpWeight());

        sourceListLayout = new LinearLayout(this);
        sourceListLayout.setOrientation(LinearLayout.VERTICAL);
        root.addView(sourceListLayout, mp(-1, -2));

        addSectionTitle(root, "3. 搜索结果 / 下载");
        resultLayout = new LinearLayout(this);
        resultLayout.setOrientation(LinearLayout.VERTICAL);
        root.addView(resultLayout, mp(-1, -2));

        addSectionTitle(root, "4. 运行日志");
        logView = new TextView(this);
        logView.setTextSize(12);
        logView.setText("等待操作。\n");
        root.addView(logView, mp(-1, -2));

        setContentView(scrollView);
    }

    private void addSectionTitle(LinearLayout root, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(17);
        tv.setPadding(0, dp(18), 0, dp(6));
        root.addView(tv, mp(-1, -2));
    }

    private void readClipboard(boolean searchAfterRead) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) {
                toast("剪贴板为空");
                return;
            }
            ClipData clip = cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) {
                toast("剪贴板为空");
                return;
            }
            CharSequence text = clip.getItemAt(0).coerceToText(this);
            if (text == null || text.toString().trim().isEmpty()) {
                toast("剪贴板没有文字");
                return;
            }
            String cleaned = cleanBookName(text.toString());
            bookInput.setText(cleaned);
            log("读取剪贴板：" + cleaned);
            if (searchAfterRead) searchAllSources();
        } catch (Exception e) {
            toast("读取剪贴板失败：" + e.getMessage());
            log("读取剪贴板失败：" + e.getMessage());
        }
    }

    private String cleanBookName(String raw) {
        String s = raw == null ? "" : raw.trim();
        s = s.replaceAll("[《》]", "");
        s = s.replaceAll("\\s+", " ");
        if (s.length() > 120) s = s.substring(0, 120);
        return s;
    }

    private void addSource() {
        String name = sourceNameInput.getText().toString().trim();
        String template = sourceTemplateInput.getText().toString().trim();
        String ext = sourceExtInput.getText().toString().trim();
        if (name.isEmpty()) {
            toast("请填写资源站名称");
            return;
        }
        if (!template.contains("{keyword}") && !template.contains("{keyword_raw}")) {
            toast("搜索链接模板必须包含 {keyword} 或 {keyword_raw}");
            return;
        }
        sources.add(new SourceConfig(name, template, ext.isEmpty() ? "pdf,zip" : ext, true));
        saveSources();
        renderSources();
        sourceNameInput.setText("");
        sourceTemplateInput.setText("");
        toast("已添加资源站");
    }

    private void renderSources() {
        if (sourceListLayout == null) return;
        sourceListLayout.removeAllViews();
        for (int i = 0; i < sources.size(); i++) {
            SourceConfig s = sources.get(i);
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(8), dp(8), dp(8), dp(8));

            TextView tv = new TextView(this);
            tv.setText((s.enabled ? "✅ " : "⛔ ") + s.name + "\n" + s.template + "\n允许类型：" + s.allowedExt);
            tv.setTextSize(13);
            box.addView(tv, mp(-1, -2));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            final int idx = i;
            Button toggle = new Button(this);
            toggle.setText(s.enabled ? "停用" : "启用");
            toggle.setOnClickListener(v -> {
                sources.get(idx).enabled = !sources.get(idx).enabled;
                saveSources();
                renderSources();
            });
            row.addView(toggle, lpWeight());
            Button delete = new Button(this);
            delete.setText("删除");
            delete.setOnClickListener(v -> {
                sources.remove(idx);
                saveSources();
                renderSources();
            });
            row.addView(delete, lpWeight());
            box.addView(row, mp(-1, -2));
            sourceListLayout.addView(box, mp(-1, -2));
        }
    }

    private void openSearchPages() {
        String keyword = bookInput.getText().toString().trim();
        if (keyword.isEmpty()) {
            toast("请先填写或读取书名");
            return;
        }
        int count = 0;
        for (SourceConfig s : sources) {
            if (!s.enabled) continue;
            try {
                String url = buildSearchUrl(s.template, keyword);
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                count++;
            } catch (Exception e) {
                log("打开搜索页失败：" + s.name + "，" + e.getMessage());
            }
        }
        if (count == 0) toast("没有启用的资源站");
    }

    private void searchAllSources() {
        String keyword = bookInput.getText().toString().trim();
        if (keyword.isEmpty()) {
            toast("请先填写或读取书名");
            return;
        }
        latestResults.clear();
        resultLayout.removeAllViews();
        log("开始搜索：" + keyword);
        int enabledCount = 0;
        for (SourceConfig source : sources) {
            if (!source.enabled) continue;
            enabledCount++;
            executor.execute(() -> searchSource(source, keyword));
        }
        if (enabledCount == 0) toast("没有启用的资源站");
    }

    private void searchSource(SourceConfig source, String keyword) {
        try {
            String searchUrl = buildSearchUrl(source.template, keyword);
            postLog("搜索 " + source.name + "：" + searchUrl);

            if (looksLikeFileUrl(searchUrl, source.allowedExt)) {
                SearchResult direct = new SearchResult(source.name, "直接下载链接", searchUrl, 100);
                addResult(direct);
                return;
            }

            HttpURLConnection conn = (HttpURLConnection) new URL(searchUrl).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(18000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) BookAutoDownloader/1.0");
            int code = conn.getResponseCode();
            String contentType = conn.getContentType();
            if (contentType != null && !contentType.toLowerCase(Locale.ROOT).contains("text/html") && looksLikeDownloadContent(contentType)) {
                SearchResult direct = new SearchResult(source.name, "服务器返回可下载文件", conn.getURL().toString(), 100);
                addResult(direct);
                conn.disconnect();
                return;
            }
            if (code < 200 || code >= 400) {
                postLog(source.name + " 返回状态码：" + code);
                conn.disconnect();
                return;
            }
            String html = readText(conn.getInputStream(), guessCharset(contentType));
            conn.disconnect();

            ArrayList<SearchResult> found = parseLinks(source.name, searchUrl, html, keyword, source.allowedExt);
            if (found.isEmpty()) {
                postLog(source.name + " 未解析到可下载链接。可能是动态页面、需要登录、验证码或网站规则不匹配。可用“打开搜索页”手动处理。");
            }
            for (SearchResult r : found) addResult(r);
        } catch (Exception e) {
            postLog(source.name + " 搜索失败：" + e.getMessage());
        }
    }

    private String buildSearchUrl(String template, String keyword) throws Exception {
        String encoded = URLEncoder.encode(keyword, "UTF-8");
        return template.replace("{keyword}", encoded).replace("{keyword_raw}", keyword);
    }

    private void addResult(SearchResult result) {
        mainHandler.post(() -> {
            latestResults.add(result);
            Collections.sort(latestResults, (a, b) -> b.score - a.score);
            renderResults();
            if (autoDownloadCheck.isChecked() && latestResults.size() == 1 && result.score >= MATCH_AUTO_DOWNLOAD_MIN_SCORE) {
                downloadResult(result);
            }
        });
    }

    private void renderResults() {
        resultLayout.removeAllViews();
        int limit = Math.min(latestResults.size(), 20);
        for (int i = 0; i < limit; i++) {
            SearchResult r = latestResults.get(i);
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(8), dp(8), dp(8), dp(8));

            TextView tv = new TextView(this);
            tv.setText("【" + r.sourceName + "】匹配度 " + r.score + "%\n" + r.title + "\n" + r.url);
            tv.setTextSize(13);
            box.addView(tv, mp(-1, -2));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            Button dl = new Button(this);
            dl.setText("下载");
            dl.setOnClickListener(v -> downloadResult(r));
            row.addView(dl, lpWeight());
            Button open = new Button(this);
            open.setText("浏览器打开");
            open.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(r.url))));
            row.addView(open, lpWeight());
            box.addView(row, mp(-1, -2));
            resultLayout.addView(box, mp(-1, -2));
        }
    }

    private ArrayList<SearchResult> parseLinks(String sourceName, String baseUrl, String html, String keyword, String allowedExt) {
        ArrayList<SearchResult> list = new ArrayList<>();
        Pattern p = Pattern.compile("<a\\s+[^>]*href\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher m = p.matcher(html);
        Set<String> seen = new HashSet<>();
        while (m.find()) {
            try {
                String href = m.group(1);
                String text = stripHtml(m.group(2));
                if (href == null || href.trim().isEmpty()) continue;
                String abs = new URL(new URL(baseUrl), href.trim()).toString();
                if (seen.contains(abs)) continue;
                if (!looksLikeFileUrl(abs, allowedExt) && !looksLikeDownloadText(text)) continue;
                int score = score(keyword, text + " " + abs);
                if (score < 18 && !looksLikeFileUrl(abs, allowedExt)) continue;
                if (text.isEmpty()) text = guessTitleFromUrl(abs);
                list.add(new SearchResult(sourceName, text, abs, score));
                seen.add(abs);
            } catch (Exception ignore) {
            }
        }
        Collections.sort(list, (a, b) -> b.score - a.score);
        ArrayList<SearchResult> top = new ArrayList<>();
        int count = Math.min(list.size(), 10);
        for (int i = 0; i < count; i++) top.add(list.get(i));
        return top;
    }

    private boolean looksLikeFileUrl(String url, String allowedExt) {
        if (url == null) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        String[] parts = allowedExt == null ? new String[]{"pdf", "zip"} : allowedExt.split(",");
        for (String raw : parts) {
            String ext = raw.trim().toLowerCase(Locale.ROOT);
            if (ext.isEmpty()) continue;
            if (lower.contains("." + ext)) return true;
        }
        return lower.contains("download") || lower.contains("file=") || lower.contains("attachment");
    }

    private boolean looksLikeDownloadText(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(Locale.ROOT);
        return t.contains("下载") || t.contains("download") || t.contains("pdf") || t.contains("zip") || t.contains("附件");
    }

    private boolean looksLikeDownloadContent(String contentType) {
        String t = contentType.toLowerCase(Locale.ROOT);
        return t.contains("pdf") || t.contains("zip") || t.contains("octet-stream") || t.contains("application/");
    }

    private String stripHtml(String s) {
        if (s == null) return "";
        return s.replaceAll("<[^>]+>", " ")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String guessTitleFromUrl(String url) {
        try {
            String path = Uri.parse(url).getLastPathSegment();
            if (path == null || path.isEmpty()) return "未命名文件";
            return Uri.decode(path);
        } catch (Exception e) {
            return "未命名文件";
        }
    }

    private int score(String keyword, String candidate) {
        String a = normalize(keyword);
        String b = normalize(candidate);
        if (a.isEmpty() || b.isEmpty()) return 0;
        int bonus = 0;
        if (b.contains(a)) bonus += 45;
        String[] tokens = a.split(" ");
        int tokenHit = 0;
        for (String t : tokens) {
            if (t.length() >= 2 && b.contains(t)) tokenHit++;
        }
        if (tokens.length > 0) bonus += (int) (30.0 * tokenHit / tokens.length);
        double dice = diceSimilarity(a, b);
        int result = (int) Math.min(100, bonus + dice * 55);
        return Math.max(0, result);
    }

    private String normalize(String s) {
        if (s == null) return "";
        return s.toLowerCase(Locale.ROOT)
                .replaceAll("[《》\\[\\]【】()（）{}<>.,，。:：;；!！?？_\\-]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private double diceSimilarity(String a, String b) {
        Set<String> aa = bigrams(a);
        Set<String> bb = bigrams(b);
        if (aa.isEmpty() || bb.isEmpty()) return 0;
        int inter = 0;
        for (String x : aa) if (bb.contains(x)) inter++;
        return (2.0 * inter) / (aa.size() + bb.size());
    }

    private Set<String> bigrams(String s) {
        Set<String> set = new HashSet<>();
        s = s.replace(" ", "");
        if (s.length() == 1) {
            set.add(s);
            return set;
        }
        for (int i = 0; i < s.length() - 1; i++) set.add(s.substring(i, i + 2));
        return set;
    }

    private String readText(InputStream in, Charset charset) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, charset));
        StringBuilder sb = new StringBuilder();
        String line;
        int max = 700_000;
        while ((line = br.readLine()) != null && sb.length() < max) sb.append(line).append('\n');
        br.close();
        return sb.toString();
    }

    private Charset guessCharset(String contentType) {
        try {
            if (contentType != null) {
                String[] parts = contentType.split(";");
                for (String p : parts) {
                    p = p.trim().toLowerCase(Locale.ROOT);
                    if (p.startsWith("charset=")) return Charset.forName(p.substring(8).trim());
                }
            }
        } catch (Exception ignore) {}
        return Charset.forName("UTF-8");
    }

    private void downloadResult(SearchResult r) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) {
                toast("系统下载服务不可用");
                return;
            }
            Uri uri = Uri.parse(r.url);
            DownloadManager.Request req = new DownloadManager.Request(uri);
            req.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setTitle(safeFileName(r.title));
            req.setDescription("来自：" + r.sourceName);
            String fileName = safeFileName(guessFileName(r));
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            dm.enqueue(req);
            toast("已交给系统下载器：" + fileName);
            log("开始下载：" + r.url);
        } catch (Exception e) {
            toast("下载失败：" + e.getMessage());
            log("下载失败：" + e.getMessage());
        }
    }

    private String guessFileName(SearchResult r) {
        String fromUrl = guessTitleFromUrl(r.url);
        if (fromUrl.contains(".")) return fromUrl;
        String ext = ".pdf";
        String lower = r.url.toLowerCase(Locale.ROOT);
        if (lower.contains(".zip")) ext = ".zip";
        else if (lower.contains(".rar")) ext = ".rar";
        else if (lower.contains(".7z")) ext = ".7z";
        return r.title + ext;
    }

    private String safeFileName(String s) {
        if (s == null || s.trim().isEmpty()) return "download_file";
        s = s.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (s.length() > 80) s = s.substring(0, 80);
        return s;
    }

    private void loadSources() {
        sources.clear();
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String json = sp.getString(KEY_SOURCES, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                sources.add(new SourceConfig(
                        o.optString("name"),
                        o.optString("template"),
                        o.optString("allowedExt", "pdf,zip"),
                        o.optBoolean("enabled", true)
                ));
            }
        } catch (JSONException ignore) {}
    }

    private void saveSources() {
        JSONArray arr = new JSONArray();
        try {
            for (SourceConfig s : sources) {
                JSONObject o = new JSONObject();
                o.put("name", s.name);
                o.put("template", s.template);
                o.put("allowedExt", s.allowedExt);
                o.put("enabled", s.enabled);
                arr.put(o);
            }
        } catch (JSONException ignore) {}
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_SOURCES, arr.toString()).apply();
    }

    private void postLog(String msg) {
        mainHandler.post(() -> log(msg));
    }

    private void log(String msg) {
        String old = logView == null ? "" : logView.getText().toString();
        if (old.length() > 6000) old = old.substring(0, 3000);
        logView.setText(msg + "\n" + old);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private LinearLayout.LayoutParams mp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private LinearLayout.LayoutParams lpWeight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class SourceConfig {
        String name;
        String template;
        String allowedExt;
        boolean enabled;
        SourceConfig(String name, String template, String allowedExt, boolean enabled) {
            this.name = name;
            this.template = template;
            this.allowedExt = allowedExt;
            this.enabled = enabled;
        }
    }

    private static class SearchResult {
        String sourceName;
        String title;
        String url;
        int score;
        SearchResult(String sourceName, String title, String url, int score) {
            this.sourceName = sourceName;
            this.title = title;
            this.url = url;
            this.score = score;
        }
    }
}
