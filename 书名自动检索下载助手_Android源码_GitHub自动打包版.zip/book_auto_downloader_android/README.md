# 书名自动检索下载助手 APK 源码包

这是一个原生 Android Java 项目，用于：

复制书名 → 打开 APP → 读取剪贴板 → 按你填写的资源站搜索模板自动搜索 → 解析搜索结果 → 按匹配度排序 → 下载文件到手机 Download 文件夹。

> 仅用于你有权使用的网站：自有资料站、授权资料站、公版/开放授权资料库、企业内部资料库。不要用于自动搜索、下载、分发未授权电子书/教材/小说/扫描书。

## 已实现功能

1. 手动读取剪贴板内容。
2. 支持多个资源站配置。
3. 支持 `{keyword}` 自动 URL 编码替换。
4. 支持 `{keyword_raw}` 原文替换。
5. 自动请求搜索页面。
6. 自动解析 HTML 页面里的 `<a href>` 下载链接。
7. 按书名相似度排序。
8. 可手动点击下载。
9. 可勾选“搜索后自动下载最高匹配结果”。
10. 支持用系统 DownloadManager 下载到手机 Download 文件夹。
11. 如果网站需要登录、验证码或动态 JS 页面，可以点击“打开搜索页”手动处理。
12. 已包含 GitHub Actions 云端打包 APK 配置。

## 手机上传 GitHub 后自动打包 APK

### 1. 下载本项目 ZIP

把这个源码包上传到 GitHub 的新仓库。

### 2. 手机创建 GitHub 仓库

在手机浏览器打开 GitHub：

- New repository
- Repository name：`book-auto-downloader-android`
- Public / Private 都可以
- Create repository

### 3. 上传项目文件

进入仓库后选择：

- Add file
- Upload files

上传源码包里的所有文件，尤其要保证这些文件在仓库根目录：

```text
settings.gradle
build.gradle
app/build.gradle
app/src/main/AndroidManifest.xml
.github/workflows/build-apk.yml
```

不要让项目多套一层文件夹。仓库根目录应该直接看到 `app` 文件夹和 `.github` 文件夹。

### 4. 运行 GitHub Actions

上传完成后：

- 打开仓库的 Actions 页面
- 选择 Build Debug APK
- 点 Run workflow
- 等待构建完成

### 5. 下载 APK

构建成功后，在 Actions 的构建记录底部找到 Artifacts：

```text
书名自动检索下载助手-debug-apk
```

下载并解压，里面有：

```text
书名自动检索下载助手-debug.apk
```

下载安装到安卓手机即可。第一次安装可能需要允许“安装未知来源应用”。

## APP 使用方法

### 添加资源站

搜索链接模板必须包含 `{keyword}` 或 `{keyword_raw}`。

例子：

```text
资源站名称：我的资料站
搜索链接模板：https://example.com/search?q={keyword}
允许下载类型：pdf,zip
```

如果网站要求不编码中文，可以用：

```text
https://example.com/search?q={keyword_raw}
```

### 搜索下载

1. 在别的 APP 里复制书名。
2. 打开本 APP。
3. 点“读取剪贴板”。
4. 点“开始搜索”。
5. 在结果里点“下载”。

如果你勾选了“搜索后自动下载最高匹配结果”，APP 会在匹配度足够高时自动下载第一个结果。

## 注意限制

1. Android 10 以后，后台 APP 不能随便读取剪贴板，所以必须打开 APP 或点按钮后读取。
2. 纯 HTML/PWA 不能稳定自动下载外部网站文件，因此这个版本是原生 Android APK。
3. 只能解析普通 HTML 页面里的链接。动态 JS、验证码、登录态、反爬虫页面无法保证自动解析。
4. 如果网站有公开 API，建议把搜索模板改成 API 地址，稳定性更高。
5. 下载后的文件在手机的 Download/下载 文件夹。
